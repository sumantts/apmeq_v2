<?php

namespace Picqer\Barcode\Exceptions;

class InvalidFormatException extends BarcodeException {}